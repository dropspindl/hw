module ApplicationHelper

  def auth_token
    #the solution link is broken, and fuck if I know
  end
end
